from __future__ import absolute_import

import sys

sys.path.append('.')
sys.path.append('../api')
sys.path.append('../models')
sys.path.append('../')

import uuid
import json
import unittest
import requests
from exchange_rate_controller_api import ExchangeRateControllerApi  # noqa: E501
from rest import ApiException
from exchange_rate_request import ExchangeRateRequest
from VeemError import VeemError


class TestExchangeRateControllerApi(unittest.TestCase):
    """ExchangeRateControllerApi unit test stubs"""

    def setUp(self):
        self.api = ExchangeRateControllerApi()  # noqa: E501

    def tearDown(self):
        pass

    def testCorrectInput(self):
        """Test case for generate_exchange_quote_using_post

        """
        test_controller = ExchangeRateControllerApi()  
        
        request = ExchangeRateRequest(to_amount=100.0,from_currency='USD', to_country='IN', to_currency='INR', recipient_account_email='hi@gm.com')
        response=test_controller.create_quote_using_post(request)
        assert response.id is not None and response.expiry is not None and response.to_currency=='INR' and response.rate>50 and response.rate<100
        
           
    def testNeitherAmount(self):
        test_controller = ExchangeRateControllerApi()  
        request = ExchangeRateRequest(from_currency='USD', to_country='IN', to_currency='INR', recipient_account_email='hi@gm.com')
        try: 
            response=test_controller.create_quote_using_post(request)
        except VeemError as error:
            assert error.code==50001403 
        else:
            self.fail('VeemError not raised correctly')  
        
    def testBothAmounts(self):
        test_controller = ExchangeRateControllerApi()  
        request = ExchangeRateRequest(to_amount=100.0,from_amount=100.0,from_currency='USD', to_country='IN', to_currency='INR', recipient_account_email='hi@gm.com')
        try: 
            response=test_controller.create_quote_using_post(request)
        except VeemError as error:
            assert error.code==50001402
        else:
            self.fail('VeemError not raised correctly')  
    
    def testMissingOthers(self):
        test_controller = ExchangeRateControllerApi()  
        request = ExchangeRateRequest(to_amount=100.0, to_country='IN', to_currency='INR', recipient_account_email='hi@gm.com')
        try: 
            response=test_controller.create_quote_using_post(request)
        except VeemError as error:
           assert error.code==100
        else:
            self.fail('VeemError not raised correctly')  
     
    

if __name__ == '__main__':
    unittest.main()
