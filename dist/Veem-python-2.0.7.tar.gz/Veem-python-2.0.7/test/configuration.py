class Configuration(object):
    def __init__(self):
        # access token for OAuth
        self.access_token = "Bearer 1402be2f-e9fd-45e8-81ed-8dedbaa43b6a"
